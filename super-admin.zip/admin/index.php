<?php
include_once("config.php");
echo "<script>window.location.href='dashboard'</script>";
