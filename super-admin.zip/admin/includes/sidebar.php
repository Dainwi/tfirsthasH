<div class="page-sidebar">
  <a class="logo" href="#">First Hash</a>
  <ul class="list-unstyled accordion-menu">
    <li>
      <a href="../dashboard/"><i data-feather="activity"></i>Dashboard</a>
    </li>
    <li>
      <a href="../plan"><i data-feather="star"></i>Plans</a>
    </li>
    <li>
      <a href="../coupon"><i data-feather="gift"></i>Coupons</a>
    </li>
    <li>
      <a href="../clients"><i data-feather="users"></i>Clients</a>
    </li>
    <li>
      <a href="../transaction"><i data-feather="dollar-sign"></i>transaction</a>
    </li>
    <li class="active-page">
      <a href="#" class="active"><i data-feather="star"></i>Pages<i class="fas fa-chevron-right dropdown-icon"></i></a>
      <ul class="">
        <li><a href="../"><i class="far fa-circle"></i>Login</a></li>
        <li><a href="register.html"><i class="far fa-circle"></i>Register</a></li>
      </ul>
    </li>
  </ul>
  <a href="#" id="sidebar-collapsed-toggle"><i data-feather="arrow-right"></i></a>
</div>
<div class="page-content">