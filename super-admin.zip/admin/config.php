<?php
$host = 'localhost';
// $username = 'u472333726_Dainwi';
// $password = 'D123a456@7';
// $dbname = 'u472333726_tfirst_hash';
$username = 'root';
$password = '';
$dbname = 'firsthash';
$rkey ="rzp_test_fu30wZNoNncFmY";
$rname = "First Hash";
$raddress = "Road No. 13 E, Om Prakash Nagar Basargarh, Hatia, Ranchi, JH-03";
$rcolor = "#F37254";

$url = 'http://localhost/tfirsthash/';

$con = mysqli_connect("$host", "$username", "$password", "$dbname") or die("connection failed");